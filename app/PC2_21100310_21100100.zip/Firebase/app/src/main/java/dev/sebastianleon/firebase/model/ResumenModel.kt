package dev.sebastianleon.firebase.model

data class ResumenModel(
    val ingreso: String = "",
    val costo: String = "",
)
