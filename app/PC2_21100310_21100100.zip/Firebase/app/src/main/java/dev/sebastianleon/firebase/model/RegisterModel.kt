package dev.sebastianleon.firebase.model

data class RegisterModel(
    val fecha: String = "",
    val descripcion: String = "",
    val monto: String = ""
)
