package dev.sebastianleon.firebase.model

data class UserModel (
    val email: String = "",
    val uid: String? = ""
)
